import React from 'react';
import { View, Text, Button, FlatList, ActivityIndicator, TouchableOpacity } from 'react-native'; 
import { ListItem, SearchBar } from 'react-native-elements';

export default class HomeScreen extends React.Component {
  static navigationOptions = {
    title: "Home"
  }
  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
    }
  };

  renderHeader = () => {
    return <SearchBar placeholder="Type here..." lightTheme round />
  };

  renderFooter = () => {
    return (
      <View style={{paddingVertical: 20}}>
        <ActivityIndicator animating size='small' />
      </View>
    )
  };

  render() {
    if(this.state.isLoading){
      return(
        <View style={{flex: 1, padding: 20, justifyContent: 'center'}}>
          <ActivityIndicator/>
        </View>
      )
    }
    return(
      <View style={{flex: 1, paddingTop:20}}>
        <FlatList
          data={this.state.dataSource}
          renderItem={({item}) => (
            <TouchableOpacity onPress={() => { this.props.navigation.navigate('Details', {id: item.i}) }}>
              <ListItem
                roundAvatar
                title={`${item.t}`}
                subtitle={`${item.c}`}
                avatar={{ uri: "https://cdn.mangaeden.com/mangasimg/" + item.im}}
              />
            </TouchableOpacity>
          )}
          keyExtractor={item => item.i}
          ListHeaderComponent = {this.renderHeader}
          ListFooterComponent = {this.renderFooter}
        />
      </View>
    );
  }
  componentDidMount() {

    return fetch('https://www.mangaeden.com/api/list/0/')
    .then((response) => response.json())
    .then((responseJson) => {

      this.setState({
        isLoading: false,
        dataSource: responseJson.manga,
      }, function(){

      });

    })
    .catch((error) =>{
      console.error(error);
    });
  }
}