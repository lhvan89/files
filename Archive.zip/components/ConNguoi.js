import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';

export default class ConNguoi extends React.Component {
    constructor(props){
        super(props);
        this.state={
            chieucao:0
        }
    }
  
    clickMe() {
        this.setState({
            chieucao: this.state.chieucao + 100
        });
    }
    render() {
  
      return(
        <TouchableOpacity onPress={() => {this.clickMe()}}>
            <View style={styles.bao}>
            <Text>{this.props.name}</Text>
            <Text>{this.state.chieucao}</Text>
            </View>
        </TouchableOpacity>

      );
    }
  }
  const styles = StyleSheet.create({
    bao: {
        width:100,
        height: 100,
        backgroundColor: 'red',
        margin: 10
    },
  });