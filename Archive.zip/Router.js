import React from 'react';
import { StackNavigator} from 'react-navigation';
import Home from './components/Home.js';
import Detail from './components/Detail.js';

export const HomeStack = StackNavigator({
    HomeScreen: {
        screen: Home
    }
})